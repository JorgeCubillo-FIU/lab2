from pip._vendor.typing_extensions import Self
from RemoteControlRobot import *
import FloorMap
import Position
import Command
import Sensor
import Transceiver
import Battery 
from json import scanner




class robot:
    def __init__(self, robotId, robotPosition, robotSensor, robotBattery, robotMap, robotCarryingPod):
        self.robotId = robotId
        self.robotPosition = robotPosition
        self.robotSensor = robotSensor
        self.robotBattery = robotBattery
        self.robotMap = robotMap
        self.robotCarryingPod = robotCarryingPod

        def powerOn(self):
            print("Power is On")
        """
        METHOD TO TURN OFF ROBOT
        
        """
        def poweOff(Self):
            print("Power is Off")
            
        """
        METHOD TO MOVE ROBOT
        
        """        
        def movecommand(self):
            print("Command Executed")
            
        """
        METHOD TO FOLLO ROBOT DIRECTION IN FLOOR
                
        """  
            
        def robotMap(self):
            print("follow Destination"+self.robotMap)
            
        """
        METHOD CARRYING POD
                
        """ 
        
        def isCarryingPod(self):
            print("Is Carrying Pod Yes or No")
            
        """
        METHOD POD WAS SUCCESFULLY DROPPED
                
        """ 
            
        def isSuccessFullyDropped(Self):
            print("It was successfully dropped to destination")  

    """
    Add the entry actions for each state
    """
    def robot(self, initiate):
        if initiate == 0:        # This will allow robot to move once received the message 
            self._move.cancel()
            self._message.go()
            print("Robot Initiate movement")
        elif initiate == 1:      # This will allow the robot to initiate and locate 
            self._move_data_entries()
            self._locate.start(100)
            print("Robot Calibrate")
            
    def sensor(self, scanner):
        if scanner == 1:
            self._scan.ProductionCode()
            self._floorMap()
            print("Robot Item Found")
        elif scanner == 0:
            self.scan.produce_global_ext()
            self._floorMap()
        print("Robot Item not Found")
    
    def position(self, location):
        if location == 1:
            self._pickPod()
            self._floorMap()
            print("Robot Picked Pod")
    def battery(self, charger):
        if charger == 0:
            self.battery(charger)
            print("Return to Station")
    
        
    
            
        
