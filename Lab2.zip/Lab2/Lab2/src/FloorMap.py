class FloorMap:
    def getObjectAtLocation(self): #get object at the location
        print("Object has been located")
    def getInitialRobotPosition(self): #get initial Robot Position at Warehouse Floor
        print("Robot check initial position")
    def getMinRowNum(self):
        print("Robot gets Min Row Number")
    def getMaxRowNum(self):
        print("Robot gets Max Row Number")     
    def getMaxColNum(self):
        print("Robot gets Max Column Number")
    def getMinColNum(self):
        print("Robot gets Min Column Number")